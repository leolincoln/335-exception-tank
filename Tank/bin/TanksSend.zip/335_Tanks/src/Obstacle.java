
public interface Obstacle {
	
	
	public void recieveDamage(int dmg);
	
	public boolean removeObstacle();
	
	public int getHealth();
	
	public Point getLocation();
	
	

}
