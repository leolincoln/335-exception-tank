
public class Sand implements Terrain {

}
