
public class Ice implements Terrain {

}
