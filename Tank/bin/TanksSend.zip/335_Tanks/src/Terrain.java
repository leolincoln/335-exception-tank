
public interface Terrain {

}
