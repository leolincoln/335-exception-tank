
public class Grass implements Terrain {
	
	

}
